package assignment2;

import java.io.Serializable;

public class BusinessGuest extends Guest implements Serializable
{
	private String phone;
    private int memberNumber;
    private Business businessName;

	public BusinessGuest(String guestName, String phone, int memberNumber, Business businessName) 
	{
		super(guestName);
		this.phone = phone;
		this.memberNumber = memberNumber;
		this.businessName = businessName;
	}

	/**
	 * @return the phone
	 */
	public String getPhone() {
		return phone;
	}

	/**
	 * @param phone the phone to set
	 */
	public void setPhone(String phone) {
		this.phone = phone;
	}

	/**
	 * @return the memberNumber
	 */
	public int getMemberNumber() {
		return memberNumber;
	}

	/**
	 * @param memberNumber the memberNumber to set
	 */
	public void setMemberNumber(int memberNumber) {
		this.memberNumber = memberNumber;
	}

	/**
	 * @return the businessName
	 */
	public Business getBusinessName() {
		return businessName;
	}

	/**
	 * @param businessName the businessName to set
	 */
	public void setBusinessName(Business businessName) {
		this.businessName = businessName;
	}

	@Override
	public String getContactDetails() {
		return "Phone: " + this.getPhone() + ", Business: " + this.getBusinessName().getName()+ ", Member #: " + this.getMemberNumber();
    }
}
