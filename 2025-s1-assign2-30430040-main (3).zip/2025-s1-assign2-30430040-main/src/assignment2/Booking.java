package assignment2;

import java.io.Serializable;

/** A booking by a guest */
public class Booking implements Serializable
{
	private Guest guest;		// Who is the guest that this booking is for?
	private int startDay;		// The day of the first night that is included in booking
	private int endDay;			// The day of the last night that is included in booking (can be same as startDay)
	private Room room;			// One part of a bi-directional reference. The room will also have a reference back to this (when booked).

	public Booking(Guest guest, int startDay, int endDay) {
		this.guest = guest;
		this.startDay = startDay;
		this.endDay = endDay;
		room = null;
	}
	
	/** Record the Room which this booking is for. */
	public void setRoom(Room bookedRoom)
	{
		this.room = bookedRoom;
	}
	
	/** Retrieve the Room that this booking is for. */ 
	public Room getRoom()
	{
		return room;
	}

	/** Determine the guest that this booking is for. */
	public Guest getGuest() {
		return guest;
    }

	/** Return the day this booking commences. */
	public int getStartDay() {
		return startDay;
    }

	/** Return the day this booking concludes (the final night included). */
	public int getEndDay() {
		return endDay;
    }

}