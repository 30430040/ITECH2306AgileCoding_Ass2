package assignment2;

import java.util.ArrayList;
import java.io.Serializable;

public class Business implements Serializable
{
    private String name;
    private String contactPerson;
    private ArrayList<BusinessGuest> employees;

    public Business(String name, String contactPerson) {
        this.name = name;
        this.contactPerson = contactPerson;
        this.employees = new ArrayList<>();
    }

    public void addEmployee(BusinessGuest guest) {
        employees.add(guest);
    }

    public String getName() {
        return name;
    }

    public String getContactPerson()
    {
    	return contactPerson;
    }
    public ArrayList<BusinessGuest> getEmployees() {
        return employees;
    }
}
