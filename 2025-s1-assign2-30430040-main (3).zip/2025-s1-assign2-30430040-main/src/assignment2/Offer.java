package assignment2;

public interface Offer 
{
    double applyDiscount(double originalCost, RoomType roomType, int[] stayDays);
}
