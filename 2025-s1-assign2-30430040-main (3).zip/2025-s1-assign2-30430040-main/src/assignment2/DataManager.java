package assignment2;

public class DataManager {

	public DataManager() {
		// TODO Auto-generated constructor stub
	}

}
