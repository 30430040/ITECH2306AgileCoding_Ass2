package assignment2;

public class BookingIDGenerator 
{
    private static int nextId = 100;

    public static int getNextId() {
        return nextId++;
    }
}

