package assignment2;

// These are essentially constants.

public enum RoomType {
    BASIC_SINGLE_SUITE,
    DELUXE_SUITE,
    EXECUTIVE_SUITE
}
