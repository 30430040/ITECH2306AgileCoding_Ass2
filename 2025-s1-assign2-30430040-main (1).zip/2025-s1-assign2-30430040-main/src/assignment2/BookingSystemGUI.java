package assignment2;

public class BookingSystemGUI {

	public BookingSystemGUI() {
		// TODO Auto-generated constructor stub
	}

}
