package assignment2;

public abstract class Guest 
{
	private String guestName;
	
	public Guest(String guestName) 
	{
		this.guestName = guestName;
	}

	/**
	 * @return the guestName
	 */
	public String getGuestName() {
		return guestName;
	}

	/**
	 * @param guestName the guestName to set
	 */
	public void setGuestName(String guestName) {
		this.guestName = guestName;
	}

	public abstract String getContactDetails();
}
